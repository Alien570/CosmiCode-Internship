document.getElementById('changeBtn').addEventListener('click', () => {
  const title = document.getElementById('title');
  title.textContent = 'Text Changed!';
  title.style.color = 'blue';
  title.style.fontSize = '2em';
});
