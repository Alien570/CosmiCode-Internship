document.getElementById('signupForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const error = document.getElementById('error');

  if (!username || !email) {
    error.textContent = 'All fields are required!';
  } else if (!email.includes('@')) {
    error.textContent = 'Please enter a valid email!';
  } else {
    error.textContent = '';
    alert('Form submitted successfully!');
    document.getElementById('signupForm').reset();
  }
});
